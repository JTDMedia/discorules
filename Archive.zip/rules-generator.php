<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" href="http://discorules.justvikie.online/favicon.ico" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discord Rules Generator</title>
    <script>

        // Define rules and translations directly in JavaScript
        const rules = {
            en: [
                { title: "No swearing", description: "Avoid using offensive or inappropriate language." },
                { title: "Respect others", description: "Treat everyone with respect and courtesy." },
                { title: "No spam", description: "Do not send repetitive or irrelevant messages." },
                { title: "No NSFW content", description: "Content that is not safe for work is prohibited." },
                { title: "Follow server rules", description: "Adhere to all server-specific guidelines." },
                { title: "No self-promotion", description: "Avoid promoting yourself or others without permission." },
                { title: "Keep topics appropriate", description: "Conversations should be suitable for all members." },
                { title: "Use correct channels", description: "Post content in the relevant channels as indicated by server guidelines." }
            ],
            nl: [
                { title: "Niet vloeken", description: "Vermijd het gebruik van beledigende of ongepaste taal." },
                { title: "Respecteer anderen", description: "Behandel iedereen met respect en beleefdheid." },
                { title: "Geen spam", description: "Verstuur geen herhaalde of irrelevante berichten." },
                { title: "Geen NSFW-inhoud", description: "Inhoud die niet geschikt is voor werk is verboden." },
                { title: "Volg serverregels", description: "Houd je aan alle serverspecifieke richtlijnen." },
                { title: "Geen zelfpromotie", description: "Vermijd het promoten van jezelf of anderen zonder toestemming." },
                { title: "Houd onderwerpen gepast", description: "Gesprekken moeten geschikt zijn voor alle leden." },
                { title: "Gebruik juiste kanalen", description: "Plaats inhoud in de relevante kanalen zoals aangegeven door de serverrichtlijnen." }
            ],
            fr: [
                { title: "Pas de jurons", description: "Évitez d'utiliser un langage offensant ou inapproprié." },
                { title: "Respectez les autres", description: "Traitez tout le monde avec respect et courtoisie." },
                { title: "Pas de spam", description: "Ne pas envoyer de messages répétitifs ou hors sujet." },
                { title: "Pas de contenu NSFW", description: "Le contenu inapproprié pour le travail est interdit." },
                { title: "Suivez les règles du serveur", description: "Respectez toutes les directives spécifiques du serveur." },
                { title: "Pas d'auto-promotion", description: "Évitez de vous promouvoir ou de promouvoir les autres sans permission." },
                { title: "Gardez les sujets appropriés", description: "Les discussions doivent être adaptées à tous les membres." },
                { title: "Utilisez les bons canaux", description: "Publiez le contenu dans les canaux pertinents, comme indiqué par les directives du serveur." }
            ]
        };

        function generateRules() {
            const selectedLanguage = document.getElementById('language').value;
            const selectedRules = Array.from(document.querySelectorAll('input[name="rules"]:checked'))
                                       .map(rule => rules[selectedLanguage][parseInt(rule.value, 10)]);

            if (selectedRules.length === 0) {
                document.getElementById('result').innerText = "Please select at least one rule.";
                return;
            }

            // Format the result in Discord-style markdown
            const discordFormattedText = `# Our Rules\n` + 
                selectedRules.map((rule, index) => 
                    `## Rule ${index + 1}: ${rule.title}\n${rule.description}`
                ).join("\n\n");

            // Display the formatted text in a textarea for easy copying
            document.getElementById('result').innerHTML = `${discordFormattedText}`;
            document.getElementById('result').style.opacity = "1";
            document.getElementById('result').style.height = "200px";
        }

        function capy() {
        // Get the text field
        var copyText = document.getElementById("result");

        // Select the text field
        copyText.select();
        copyText.setSelectionRange(0, 999999); // For mobile devices

        // Copy the text inside the text field
        navigator.clipboard.writeText(copyText.value);

        // Alert the copied text
        alert("✔ Copied the text");
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&family=Sour+Gummy:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Sour Gummy', sans-serif;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
            padding: 20px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        body.dark-mode {
            background-color: #121212;
            color: #e0e0e0;
        }

        h1 {
            text-align: center;
            color: #4CAF50;
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .container {
            max-width: 960px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            position: relative;
        }

        .container.dark-mode {
            background-color: #333;
        }

        textarea {
        max-width: 960px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            transition: background-color 0.3s ease;
            position: relative;
            opacity: 0;
            height: 0px;
        }

        textarea.dark-mode {
        background-color: #333;
        }

        .footer {
            text-align: center;
            margin-top: 50px;
            font-size: 0.9rem;
            color: #aaa;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .theme-toggle {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 125px;
            height: 35px;
        }

        .theme-toggle:hover {
            background-color: #0056b3;
        }


@keyframes zoomIn {
  0% {
    transform: scale(0.8);
    opacity: 0;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}


* {
  animation: zoomIn 0.6s ease-out;
}

        .container a {
            display: inline-block;
            padding: 12px 25px;
            margin: 10px;
            text-decoration: none;
            font-size: 1.2rem;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .container a:hover {
            background-color: #0056b3;
        }

        .container select {
            display: inline-block;
            padding: 12px 25px;
            margin: 10px;
            text-decoration: none;
            font-size: 1.2rem;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .container select:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Discord Rules Generator</h1>
    <form id="rulesForm">
        <h3>Select Your Rules:</h3>
        <!-- Use the index of each rule for the value, to reference in JavaScript -->
        <input type="checkbox" name="rules" value="0"> No swearing<br>
        <input type="checkbox" name="rules" value="1"> Respect others<br>
        <input type="checkbox" name="rules" value="2"> No spam<br>
        <input type="checkbox" name="rules" value="3"> No NSFW content<br>
        <input type="checkbox" name="rules" value="4"> Follow server rules<br>
        <input type="checkbox" name="rules" value="5"> No self-promotion<br>
        <input type="checkbox" name="rules" value="6"> Keep topics appropriate<br>
        <input type="checkbox" name="rules" value="7"> Use correct channels<br>

        <h3>Select Language:</h3>
        <select id="language">
            <option value="en">English</option>
            <option value="nl">Dutch</option>
            <option value="fr">French</option>
            <!-- Add more languages here -->
        </select>

        <a onclick="generateRules()">Generate Rules</button>
    </form>
    </div>

    <center><textarea readonly style="width: 100%;" id="result" onclick="capy()"></textarea></center>

    <div class="footer">
        <p>Made with ❤️ by <a href="https://justvikie.online">JustTheDev and Vikie</a></p>
    </div>

    <center><button class="theme-toggle" onclick="toggleTheme()">Toggle Theme</button></center>

    <script>
        function applyPreferredTheme() {
            const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            document.body.classList.toggle('dark-mode', isDarkMode);
            document.querySelector('.container').classList.toggle('dark-mode', isDarkMode);
        }

        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            document.querySelector('.container').classList.toggle('dark-mode');
        }

        applyPreferredTheme();
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyPreferredTheme);
    </script>
</body>
</html>
