<?php
$webhookUrl = $_POST['webhook'] ?? '';

$data = [
    'plan' => $_POST['input'] ?? ''
];

if (empty($data['input']) || empty($webhook)) {
    http_response_code(400);
    echo "Error: Missing required fields (webhook or input).";
    exit;
}

$webhookContent = [
    "content" => "",
    "embeds" => [
        [
            "title" => "Webhook input",
            "fields" => [
                ["name" => "Input", "value" => htmlspecialchars($data['input']), "inline" => true],
            ],
            "color" => 3066993,
            "footer" => ["text" => "Send with Discorules.JustVikie.online"]
        ]
    ]
];

$ch = curl_init($webhookUrl);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($webhookContent));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode == 204) {
    http_response_code(200);
echo json_encode(['success' => 'Webhook sent']);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to send webhook']);
    exit;
}
?>